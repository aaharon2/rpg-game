--------------------------------------------
v54

fix version indexes in the README

--------------------------------------------
v53

fix version indexes in the README

-------------------------------------------
v52

fix atlas censor

--------------------------------------------
v51

fix censor on the atlas file

--------------------------------------------
v50

add free content for rpgmaker users

--------------------------------------------
v49

Add godot autotiles

--------------------------------------------
v48

Add a golden coin in the icons2 png file

--------------------------------------------
v47

Add amethyst and orange and white gemstone variation in the icons2 png file

--------------------------------------------
v46

Add emerald and sapphire variation in the icons2 png file

--------------------------------------------
v45

Add a cristal in a new icons2 png file

--------------------------------------------
v44

Adding a new color variation to chests to complete the spritesheet

--------------------------------------------
v43

Small highlight fixes on the heart and helm icons

--------------------------------------------
v42

Add doors file to the free version

--------------------------------------------
v41

Add chest and icons1 files to the free version

--------------------------------------------
v40

Add an helm to the icons1 png file

--------------------------------------------
v39

Update the icons1.png with more hearts and a shield

--------------------------------------------
v38

Testing the devlog feature on the itchio page

--------------------------------------------
v37

Testing the devlog feature on the itchio page

--------------------------------------------
v36

Testing the devlog feature on the itchio page

--------------------------------------------
v35

Testing the devlog feature on the itchio page

--------------------------------------------
v34

Testing the devlog feature on the itchio page

--------------------------------------------
v33

Testing the devlog feature on the itchio page

--------------------------------------------
v32

Testing the devlog feature on the itchio page

--------------------------------------------
v31

Split water animated tiles for an easier usage

--------------------------------------------
v30

Fixing README file and version indexes

-------------------------------------------
v29

Adding icons1 but it is work in progress

--------------------------------------------
v28

Adding a README.txt file
 
